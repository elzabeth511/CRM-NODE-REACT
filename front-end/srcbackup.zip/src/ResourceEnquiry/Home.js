export function Home() {
  return (
    <>
      <div className="homebackground">
        <div className="homesidebar1">
          <h1></h1>
        </div>
        <div className="homemain">
          <div className="crmcontent">
            
            <p className="p">
              What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the
              printing and typesetting industry. Lorem Ipsum has been the
              industry's standard dummy text ever since the 1500s, when an
              unknown printer took a galley of type and scrambled it to make a
              Aldus PageMaker including versions of Lorem Ipsum.
            </p>
            <h1><label className="our">Our</label>  Vision</h1>
           <div className="homeVision">
                
                  <img src="https://th.bing.com/th/id/OIP.TJlQ1bWb114mQPobnxQt5wHaEK?w=298&h=180&c=7&r=0&o=5&pid=1.7" />
               
               
                  <p>
                    {" "}
                    What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the
                    printing and typesetting industry. Lorem Ipsum has been the
                    industry's standard dummy text ever since the 1500s, when an
                  </p>
                


           </div>
           <h1><label className="our">Our</label> Achievements</h1>
            <div className="homeAchivements">
              <div className="no1">
                  <div><h2>No <label>1</label></h2></div>
              </div>
            </div>
          </div>
        </div>
        <div className="homesidebar2">
          <h1>contact info</h1>
          <p className="p">
            What is Lorem Ipsum? Lorem Ipsum is simply dummy text of the
           PageMaker including versions of Lorem Ipsum.
          </p>
        </div>
      </div>
    </>
  );
}



