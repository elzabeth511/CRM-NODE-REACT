
export default function  Home()
{
  
    return(
        <>
        <hr/>
        <h1> Welcome to Home</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Semper auctor neque vitae tempus quam. Tincidunt tortor aliquam nulla facilisi cras fermentum. Pretium quam vulputate dignissim suspendisse in est ante in nibh. Ut diam quam nulla porttitor. Nunc pulvinar sapien et ligula ullamcorper malesuada proin libero. Eget felis eget nunc lobortis mattis. Tellus pellentesque eu tincidunt tortor aliquam nulla facilisi. Amet cursus sit amet dictum sit amet justo donec. Malesuada pellentesque elit eget gravida cum sociis natoque. Ut tristique et egestas quis ipsum suspendisse ultrices gravida dictum.</p>
       
        </>
    );
}